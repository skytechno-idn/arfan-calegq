import React from "react";

const RelawanPage = () => {
  return <div>BELUM TERSEDIA</div>;
};

export default RelawanPage;
